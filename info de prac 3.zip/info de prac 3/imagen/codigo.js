let valorPantalla = "";
const MAX_DIGITOS = 16;

function agregarValor(valor) {
    if (valorPantalla.length >= MAX_DIGITOS) return;

    const ultimo = valorPantalla.slice(-1);
    const operadores = ['+', '-', '*', '/', '.'];
    
    // Reemplaza si hay dos operadores seguidos
    if (operadores.includes(valor) && operadores.includes(ultimo)) {
        valorPantalla = valorPantalla.slice(0, -1) + valor;
    } else {
        valorPantalla += valor;
    }
    
    actualizarPantalla();
}

function limpiarPantalla() {
    valorPantalla = "";
    actualizarPantalla();
}

function borrarUltimo() {
    valorPantalla = valorPantalla.slice(0, -1);
    actualizarPantalla();
}

function actualizarPantalla() {
    document.getElementById("pantalla").value = valorPantalla || "0";
}

function calcularResultado() {
    try {
        if (valorPantalla === "") return;

        let resultado = eval(valorPantalla);

        if (!isFinite(resultado)) {
            valorPantalla = "";
            document.getElementById("pantalla").value = "Error";
            return;
        }

        // Formato: enteros sin decimales, decimales limpios
        if (Number.isInteger(resultado)) {
            valorPantalla = resultado.toString();
        } else {
            valorPantalla = parseFloat(resultado.toFixed(8)).toString();
        }
        
        actualizarPantalla();
    } catch (error) {
        valorPantalla = "";
        document.getElementById("pantalla").value = "Error";
    }
}

// Soporte completo de teclado
document.addEventListener('keydown', function(e) {
    if ('0123456789.+-*/'.includes(e.key)) {
        e.preventDefault();
        agregarValor(e.key);
    } else if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        calcularResultado();
    } else if (e.key === 'Escape' || e.key === 'c' || e.key === 'C') {
        limpiarPantalla();
    } else if (e.key === 'Backspace') {
        borrarUltimo();
    }
});