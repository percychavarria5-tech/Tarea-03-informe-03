// --------------------------
// ELEMENTOS DEL DOM
// --------------------------
const loginLink = document.getElementById("loginLink");
const loginModal = document.getElementById("loginModal");
const closeModal = document.getElementById("closeModal");
const loginBtn = document.getElementById("loginBtn");
const username = document.getElementById("username");
const password = document.getElementById("password");
const loginMessage = document.getElementById("loginMessage");

const registroForm = document.getElementById("registroForm");
const nombre = document.getElementById("nombre");
const correo = document.getElementById("correo");
const clave = document.getElementById("clave");
const repetirclave = document.getElementById("repetirclave");
const mensaje = document.getElementById("mensaje");

const taskForm = document.querySelector("#task-form");
const taskInput = document.querySelector("#task-input");
const taskList = document.querySelector("#task-list");
const toggleThemeBtn = document.getElementById("toggle-theme-btn");

// --------------------------
// MODAL LOGIN
// --------------------------
loginLink.addEventListener("click", (e) => {
    e.preventDefault();
    loginModal.style.display = "flex";
});

closeModal.addEventListener("click", () => {
    loginModal.style.display = "none";
    loginMessage.textContent = "";
    username.value = "";
    password.value = "";
});

loginBtn.addEventListener("click", () => {
    const user = username.value;
    const pass = password.value;

    if (user === "admin" && pass === "12345") {
        loginMessage.textContent = "✅ Login exitoso!";
        loginMessage.style.color = "green";
    } else {
        loginMessage.textContent = "❌ Usuario o contraseña incorrectos.";
        loginMessage.style.color = "red";
    }
});

// --------------------------
// CARGAR DATOS GUARDADOS AL ABRIR
// --------------------------
window.addEventListener("load", () => {
    // Cargar datos del registro
    const datosGuardados = JSON.parse(localStorage.getItem("datos"));
    if (datosGuardados) {
        nombre.value = datosGuardados.nombre || "";
        correo.value = datosGuardados.correo || "";
    }
    // Cargar tareas
    loadData();
});

// --------------------------
// GUARDAR REGISTRO
// --------------------------
registroForm.addEventListener("submit", (e) => {
    e.preventDefault();

    if (clave.value !== repetirclave.value) {
        mensaje.textContent = "❌ Las contraseñas no coinciden";
        mensaje.style.color = "red";
        return;
    }

    const datos = {
        nombre: nombre.value,
        correo: correo.value,
        clave: clave.value
    };

    localStorage.setItem("datos", JSON.stringify(datos));

    mensaje.textContent = "✅ Registro guardado correctamente";
    mensaje.style.color = "green";

    setTimeout(() => mensaje.textContent = "", 3000);
});

// --------------------------
// FUNCIONES DE TAREAS
// --------------------------
function agregarBotonesSpan(texto, nombreClase) {
    const btn = document.createElement("span");
    btn.textContent = texto;
    btn.classList.add(nombreClase);
    return btn;
}

function createData(task) {
    const tasks = JSON.parse(localStorage.getItem("tasks") || "[]");
    tasks.push(task);
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

function loadData() {
    const tasks = JSON.parse(localStorage.getItem("tasks") || "[]");
    tasks.forEach(tarea => {
        const li = document.createElement("li");
        li.textContent = tarea;
        li.append(
            agregarBotonesSpan("✏️", "edit-btn"),
            agregarBotonesSpan("X", "delete-btn")
        );
        taskList.appendChild(li);
    });
}

function update() {
    const tasks = Array.from(taskList.querySelectorAll("li"))
        .map(li => li.firstChild.textContent.trim());
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

function deleteData(texto) {
    let tasks = JSON.parse(localStorage.getItem("tasks") || "[]");
    tasks = tasks.filter(tarea => tarea !== texto);
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

// Agregar tarea
taskForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const task = taskInput.value.trim();

    if (!task) return;

    const li = document.createElement("li");
    li.textContent = task;
    li.append(
        agregarBotonesSpan("✏️", "edit-btn"),
        agregarBotonesSpan("X", "delete-btn")
    );

    createData(task);
    taskList.appendChild(li);
    taskInput.value = "";
});

// Eliminar / Editar tarea
taskList.addEventListener("click", (e) => {
    const liElement = e.target.closest("li");
    if (!liElement) return;

    const textoTarea = liElement.firstChild.textContent.trim();

    if (e.target.classList.contains("delete-btn")) {
        if (confirm("¿Estás seguro de borrar este elemento?")) {
            deleteData(textoTarea);
            liElement.remove();
        }
    } else if (e.target.classList.contains("edit-btn")) {
        const nuevoTexto = prompt("Editar tarea:", textoTarea);
        if (nuevoTexto !== null && nuevoTexto.trim() !== "") {
            liElement.firstChild.textContent = nuevoTexto.trim();
            update();
        }
    }
});

// Cambiar tema
toggleThemeBtn.addEventListener("click", () => {
    document.body.classList.toggle("dark-theme");
});