// Elementos
const formulario = document.getElementById('formulario-tarea');
const entrada = document.getElementById('entrada-tarea');
const lista = document.getElementById('lista-tareas');
const botonTema = document.getElementById('boton-tema');

// Cargar tareas guardadas
let tareas = JSON.parse(localStorage.getItem('misTareas')) || [];

// Guardar en almacenamiento
function guardarTareas() {
    localStorage.setItem('misTareas', JSON.stringify(tareas));
}

// Mostrar tareas en pantalla
function renderizarTareas() {
    lista.innerHTML = '';

    tareas.forEach((contenido, indice) => {
        const li = document.createElement('li');
        li.innerHTML = `
            <span class="texto-tarea">${contenido}</span>
            <div class="botones-accion">
                <span class="editar" data-indice="${indice}">✏️</span>
                <span class="eliminar" data-indice="${indice}">🗑️</span>
            </div>
        `;
        lista.appendChild(li);
    });
}

// Agregar nueva tarea
formulario.addEventListener('submit', function (evento) {
    evento.preventDefault();
    const texto = entrada.value.trim();

    if (!texto) return;

    tareas.push(texto);
    guardarTareas();
    renderizarTareas();
    entrada.value = '';
    entrada.focus();
});

// Eliminar y editar
lista.addEventListener('click', function (evento) {
    const elemento = evento.target;
    const indice = parseInt(elemento.dataset.indice);

    // Eliminar
    if (elemento.classList.contains('eliminar')) {
        if (confirm('¿Seguro que quieres eliminar esta tarea?')) {
            tareas.splice(indice, 1);
            guardarTareas();
            renderizarTareas();
        }
    }

    // Editar
    if (elemento.classList.contains('editar')) {
        const nuevoTexto = prompt('Modificar tarea:', tareas[indice]);
        if (nuevoTexto !== null && nuevoTexto.trim() !== '') {
            tareas[indice] = nuevoTexto.trim();
            guardarTareas();
            renderizarTareas();
        }
    }
});

// Cambiar tema
botonTema.addEventListener('click', function () {
    document.body.classList.toggle('oscuro');
    const esOscuro = document.body.classList.contains('oscuro');
    this.innerHTML = esOscuro ? '☀️ Cambiar Tema' : '🌙 Cambiar Tema';
});

// Mostrar al iniciar
renderizarTareas();