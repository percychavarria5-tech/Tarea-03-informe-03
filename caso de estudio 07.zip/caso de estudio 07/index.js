const nombre = document.querySelector('#nombre');
const correo = document.querySelector('#correo');
const clave = document.querySelector('#clave');
const repetirclave = document.querySelector('#repetirclave');
const mensaje = document.querySelector('#mensaje');
const btn = document.querySelector('#btnEnviar');

btn.addEventListener('click', function () {
    mensaje.className = '';
    mensaje.textContent = '';

    if (clave.value !== repetirclave.value) {
        mensaje.className = 'error';
        mensaje.textContent = 'Las contraseñas no coinciden';
        return;
    }

    const datos = {
        nombre: nombre.value.trim(),
        correo: correo.value.trim(),
        clave: clave.value
    };

    fetch('procesa.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(datos)
    })
        .then(res => res.json())
        .then(resp => {
            if (resp.status === 200) {
                mensaje.className = 'exito';
                mensaje.textContent = resp.message;
                nombre.value = '';
                correo.value = '';
                clave.value = '';
                repetirclave.value = '';
            } else {
                mensaje.className = 'error';
                mensaje.textContent = resp.message;
            }
        })
        .catch(() => {
            mensaje.className = 'error';
            mensaje.textContent = 'Error de conexión';
        });
});