<?php
$servidor = '127.0.0.1';
$base = 'test';
$usuario = 'root';
$pass = '';
$puerto = '3306';

$conexion = mysqli_connect($servidor, $usuario, $pass, $base, $puerto);

if (!$conexion) {
    echo json_encode(['status' => 400, 'message' => 'Error de conexión']);
    exit;
}

$entrada = json_decode(file_get_contents('php://input'), true);

$nombre = trim($entrada['nombre'] ?? '');
$correo = trim($entrada['correo'] ?? '');
$clave = $entrada['clave'] ?? '';

if (empty($nombre) || empty($correo) || empty($clave)) {
    echo json_encode(['status' => 998, 'message' => 'Todos los campos son obligatorios']);
    exit;
}

if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['status' => 999, 'message' => 'Correo no válido']);
    exit;
}

$correo_seguro = mysqli_real_escape_string($conexion, $correo);
$verificar = "SELECT id FROM usuarios WHERE correo = '$correo_seguro'";
$res = mysqli_query($conexion, $verificar);

if (mysqli_num_rows($res) > 0) {
    echo json_encode(['status' => 402, 'message' => 'El correo ya está registrado']);
    exit;
}

$sql_id = "SELECT COALESCE(MAX(id), 0) + 1 AS nuevo FROM usuarios";
$fila = mysqli_fetch_assoc(mysqli_query($conexion, $sql_id));
$nuevo_id = $fila['nuevo'];

$nombre_seguro = mysqli_real_escape_string($conexion, $nombre);
$clave_segura = mysqli_real_escape_string($conexion, $clave);

$sql = "INSERT INTO usuarios (id, correo, nombre, clave, fecha_registro, estado)
        VALUES ('$nuevo_id', '$correo_seguro', '$nombre_seguro', '$clave_segura', NOW(), 1)";

if (mysqli_query($conexion, $sql)) {
    echo json_encode(['status' => 200, 'message' => 'Registro exitoso']);
} else {
    echo json_encode(['status' => 401, 'message' => 'Error al guardar']);
}

mysqli_close($conexion);